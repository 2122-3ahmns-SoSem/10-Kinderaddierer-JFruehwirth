using UnityEngine;

[CreateAssetMenu(menuName = "SoNumbersImages")]
public class SoNumberImages : ScriptableObject
{
    public Sprite[] setPoints;
}
