using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrueFalseScript : MonoBehaviour
{
    public Question[] questions;

    private void Start()
    {

    }
}