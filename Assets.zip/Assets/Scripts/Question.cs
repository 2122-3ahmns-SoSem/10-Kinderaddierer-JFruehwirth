[System.Serializable]
public class Question
{
    public string fact;
    public bool isTrue;
}
